Font usage: Free for personal use only, Non commercial

For a commercial use license visit http://www.chrisvile.com or fontmonger.com


contact: info@fontmonger.com

*** social media ***
http://www.facebook.com/fontmonger
http://www.facebook.com/designsbychris
http://www.twitter.com/fontmonger
http://www.twitter.com/chris_vile

*** My font sites ***
http://www.chrisvile.com
http://www.fontmonger.com
http://www.type512.com
http://www.fontillery.com

